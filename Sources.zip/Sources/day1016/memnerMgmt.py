import os
import sys
from day1016.memberfunc import *

if __name__ == '__main__':
    memlist = []
    while True:
        choice = inFilter("-> ", 3)
        if choice == "0":
            memlist = createNodeInit(memlist)
        elif choice == "1":
            memlist = memberAdd(memlist)
        elif choice == "2":
            memlist = memberAllList(memlist)
        elif choice == "3":
            memlist = memberSearch(memlist)
        elif choice == "4":
            memlist = memberModify(memlist)
        elif choice == "5":
            os.system("cls")
        elif choice == "6":
            sys.exit(1)
        else:
            print("잘못된 번호! 다시 입력바랍니다.")



    main()
