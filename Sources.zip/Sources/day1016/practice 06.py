while True:
    print("ㅋ", end=" ")
