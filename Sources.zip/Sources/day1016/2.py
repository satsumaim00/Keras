sum = 0
z = int(input("숫자를 입력"))

for i in range(z, 1001,z):
    sum = sum + i

else:
    print("1부터 100까지",z,"의 배수의 합은 : ", sum)
