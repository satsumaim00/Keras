# 데이터베이스 스카마 정의
# 회원: idx, name, id, eamil, major
# idx - 번호(int 8)
# mid - 아이디(varchar(50))
# name - 이름(varchar(70))
# email - 매일주소(varchar(100))
# major - 전고부냐(varchar(50))

# 요구사항, 인터페이스 정의, 설계(프로세스 설계,데이터베이스설계, 코드설계) - 개발

import os
import sys
import pymysql

sqlMemReg = "insert into memberdb.member (name, mid, email, major) values (%s, %s, %s, %s)"
sqlMemAllList = "select * from memberdb.member"
sqlmemOneSrch = "select * from memberdb.member where mid=%s"
sqlMemOneSelect = "select * from memberdb.member where mid=%s"
sqlMemOneUpdatea = "update memberdb.member set email=%s "
sqlMemOneUpdateb = "update memberdb.member set major=%s where mid=%s"
sqlMemOneUpdate = "update memberdb.member set email=%s, major=%s where mid=%s"
sqlmemOneDelete = "delete * from memberdb.member where mid=%s"
def dbConn():
    conn = pymysql.connect(host='127.0.0.1', user='root', password='1234', db='memberdb', charset='utf8')

    return conn

def displaymenu():
    print('### 회원 정보 관리 ###')
    print('1.회원등록  2.회원전체리스트  3. 회원차기, 4.정보수정, 5.정보삭제  6.화면클리어 7.종료')


def memRegister():
    global sqlMemReg
    name = input('NAME: ')
    mid = input('ID: ')
    email = input('EMAIL: ')
    major = input('MAJOR: ')

    conn = dbConn()
    try:
        with conn.cursor() as curs:
            curs.execute(sqlMemReg, (name, mid, email, major))
        conn.commit()
        print('%s is register' % (name))
    finally:
        conn.close()

def memAllListPtr():
    global sqlMemAllList

    print('--- 회원 전체 리스트 ----')
    print('번호\t아이디\t이름\t이메일\t전공')
    conn = dbConn()

    try:
        with conn.cursor() as curs:
            curs.execute(sqlMemAllList)
            rows = curs.fetchall()
            for row in rows:
                print(row[0], '\t' ,row[1], '\t',row[2],'\t',row[3], '\t', row[4])
    finally:
        conn.close()

def memOneSearch():
    global sqlmemOneSrch
    schID = input('Searching ID: ')
    conn = dbConn()
    try:
        with conn.cursor() as curs:
            curs.execute(sqlmemOneSrch, schID)
            rows = curs.fetchall()
            for row in rows:
                print(row[0], '\t', row[1], '\t', row[2], '\t', row[3], '\t', row[4])
    finally:
        conn.close()

def memInfoModify():
    schID = input('Searching ID: ')
    conn = dbConn()
    try:
        with conn.cursor() as curs:
            curs.execute(sqlMemOneSelect, schID)
            rows = curs.fetchall()
            if rows:
                for row in rows:
                    print(row[0], '\t\t', row[1], '\t', row[2], '\t', row[3], '\t', row[4])
                    Upok = input('Update 1.(email), 2,(major), 3.(all): ')
                    conn = dbConn()
                    if Upok == '1':
                        modiEmail = input('modify email: ')
                        curs.execute(sqlMemOneUpdatea, modiEmail)
                        conn.commit()
                        print("%s Member update ")
                    elif Upok == '2':
                        modiMajor = input('modify Major: ')
                        curs.execute(sqlMemOneUpdate,  modiMajor)
                        conn.commit()
                        print("%s major update")
                    elif Upok == '3':
                        modiID = input('modify email: ')
                        curs.execute(sqlMemOneUpdate, modiID)
                        conn.commit()
                    else:
                        return
                    rows = curs.fetchall()
                    if rows:
                        for row in rows:
                            print('\t'.join(map(str, row)))
            else:
                print("not fin seacrch")
                return
    finally:
        conn.close()

def sqlmemOneDelete():
    global sqlMemOneSelect
    global sqlmemOneDelete
    schID = input('Searching ID: ')
    conn = dbConn()
    try:
        with conn.cursor() as curs:
            curs.execute(sqlMemOneSelect, schID)
            rows = curs.fetchall()

            if rows:
                for row in rows:
                    print(row[0], '\t\t', row[1], '\t', row[2], '\t', row[3], '\t', row[4])
                    delok = input('Delete OK(y/n)>')
                    if delok == 'Y' or delok == 'y':
                        curs.execute(sqlmemOneDelete, schID)
                        conn.commit()
                        print("%s Member delete ")
                    elif delok == 'N' or delok == 'n':
                        print("%s Member Delete Cancel" % schID)
                        return

            else:
                print("not search")
                return
    finally:
        conn.close()


if __name__ == '__main__':
    while True:
        displaymenu()
        choice = input('-> ')

        if choice == '1':
            memRegister()
        elif choice == '2':
            memAllListPtr()
        elif choice == '3':
            memOneSearch()
        elif choice == '4':
            memInfoModify()
        elif choice == '5':
            sqlmemOneDelete()
        else:
            pass