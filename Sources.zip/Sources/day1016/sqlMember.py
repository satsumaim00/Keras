
sqlCreateDBInit = """insert into testdb.member1 (name, email, age) values (%s, %s, %s)"""
sqlMemberADD = """insert into testdb.member1 (name, email, age) values (%s, %s, %s)"""
sqlmemberAllLIST = sql = "select * from testdb.member1"
