i=1
total=0

while i <= 100 :
    if i % 2 == 0 :
        total=total+i
    i=i+1

else:
    print("1Q부터 100까지 짝수의 합 :",total)