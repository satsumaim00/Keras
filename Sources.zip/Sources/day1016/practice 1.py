sum = 0
for i in range(1,101,2) :
    sum = sum + i

else:
    print("1부터 100까지 홀수의 합은 :",sum)

sum = 0
for i in range(1,101,1) :
    sum = sum + i

else:
    print("1부터 100까지 홀수의 합은 :",sum)