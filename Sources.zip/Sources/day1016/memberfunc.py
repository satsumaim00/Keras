import os
import sys

def screen():
    print("\n### 간단한 회원 관리 프로그램 ###")
    print("0.초기생성 1. 맴버추가 2. 맴버리스트 3. 맴버찾기 4. 정보수저 5. 화면지우기 6.종료")


def createNodeInit(memlist):
    newNode = createNode()
    newNode.append("moon")
    newNode.append("sss@naver.com")
    newNode.append(22)
    newNode.append("kim")
    newNode.append("ddd@naver.com")
    newNode.append(22)
    memlist.append(newNode)
    return memlist
def createNode():
    newNode = []
    return newNode

def memberAdd(memlist):
        newNode = createNode()

        name = inFilter("이름>> ",2)
        newNode.append(name)

        email = inFilter("이메일>> ", 2)

        newNode.append(email)
        age = inFilter("나이> ", 1)
        newNode.append((age))
        memlist.append(newNode)

        return memlist

def memberAllList(memlist):
    print("-------정보-----------")
    print("이름\t\t이메일\t\t\t나이")
    for mem in memlist:
        print("%s\t%s\t %d" % (mem[0], mem[1], mem[2]))

def memberSearch(memlist):
    ser_name = inFilter("찾고싶어하는 이름 :", 2)
    for onemem in memlist:
        if ser_name in onemem:
            print("%s %s %d" % (ser_name, onemem[1], onemem[2]))
            break


def memberModify(memlist):
    ser_name = inFilter("찾고싶어하는 이름 : ", 2)
    for onemem in memlist:
        if ser_name in onemem:
            print("%s %s %d" % (ser_name, onemem[1], onemem[2]))
            break
    print("-> %s, 이메일만 변경가능함: "% onemem[1])
    onemem[1] = inFilter("이메일 수정: ", 2)
    print("변경 되었음")

def inFilter(stmt, n):
    while (True):
       if n == 1:
           choice = input(stmt)
           if choice.isalpha() == True or choice == '':pass
           else:return int(choice)
       elif n == 2:
            choice = input(stmt)
            if choice.isdigit() == True or choice == '': pass
            else: return choice
       elif n == 3:
            choice = input(stmt)
            if choice.isalpha() == True or choice == '': pass
            else: return  int(choice)




def intInFilter(stmt):
    while (True):
        value = input(stmt)
        if value.isdigit() == True or value == '':
            pass  #os.system('cls')
        else:
            break
    return value
