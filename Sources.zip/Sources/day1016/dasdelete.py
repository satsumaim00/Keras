import pymysql

delID = input('삭제할 ID: ')




conn = pymysql.connect(host='127.0.0.1', user='root', password='1234', db='testdb', charset='utf8')
curs = conn.cursor()

sql = """delete from member where memID=%s"""
curs.execute(sql, delID)
conn.commit()


print('삭제됨')
conn.close()