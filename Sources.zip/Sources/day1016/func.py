import os
import sys
import pymysql

from day1016.sqlMember import *
def screen():
    print("\n### 간단한 회원 관리 프로그램 ###")
    print("0.초기생성 1. 맴버추가 2. 맴버리스트 3. 맴버찾기 4. 정보수저 5. 화면지우기 6.종료")
def dbConnection():
    conn = pymysql.connect(host='127.0.0.1', user='root', password='1234', db='testdb', charset='utf8')
    curs = conn.cursor()
    return conn, curs

def createDBInit():
    global sqlCreateDBInit
    conn,curs = dbConnection()
    sql = """insert into testdb.member1 (name, email, age) values (%s, %s, %s)"""
    curs.execute(sql, ('temp1', 'temp1@naver.com','100'))
    #newNode = createNode()
    #newNode.append("moon")
    #newNode.append("sss@naver.com")
    #newNode.append(22)
    #newNode.append("kim")
    #newNode.append("ddd@naver.com")
    #newNode.append(22)
    #emlist.append(newNode)
   #return memlist
def createNode():
    newNode = []
    return newNode

def memberAdd():

    name = inFilter("이름>> ",2)
    email = inFilter("이메일>> ", 2)
    age = inFilter("나이> ", 1)

    conn, curs = dbConnection()

    sql = """insert into testdb.member1 (name, email, age) values (%s, %s, %s)"""
    curs.execute(sql, (name, email, age))
    conn.commit()
    conn.close()


def memberAllList():    #Select절 구문 조건 없다
    print("-------회원정보-----------")
    print("이름 \t\t 이메일 \t\t 나이")
    conn, curs = dbConnection()

    curs.execute(sqlmemberAllLIST)
    rows = curs.fetchall()

    for row in rows:
        print(row[0], '\t', row[1], '\t', row[2])

    conn.close()

    #for mem in memlist:
      #  print("%s\t%s\t %d" % (mem[0], mem[1], mem[2]))

def memberSearch():
    ser_name = inFilter("찾고싶어하는 이름 :", 2)
    conn,curs = dbConnection()

    sql = "select * from testdb.member1 where name=%s"
    curs.execute(sql, ser_name)

    rows = curs.fetchall()
    for row in rows:
        print(row[0], '\t',  row[1], '\t',row[2])
    conn.close()

    #for onemem in memlist:
     #   if ser_name in onemem:
      #      print("%s %s %d" % (ser_name, onemem[1], onemem[2]))
    #        break

def memberModify():
    ser_name = inFilter("찾고싶어하는 이름 : ", 2)
    conn,curs = dbConnection()

    sql = "select * from testdb.member1 where name=%s"
    curs.execute(sql, ser_name)

    rows = curs.fetchall()
    for row in rows:
        print(row[0], '\t',  row[1], '\t',row[2])

    modiAge = input("변경할 나이 입력-> ")
    sql = """update testdb.member1 set age=%s where name=%s"""
    curs.execute(sql, modiAge, ser_name)
    print('%s님의 나이가 수정되었음' % modiAge)
    conn.commit()
    conn.close()

    #for onemem in memlist:
     #   if ser_name in onemem:
       #     print("%s %s %d" % (ser_name, onemem[1], onemem[2]))
      #     break
    #print("-> %s, 이메일만 변경가능함: "% onemem[1])
    #onemem[1] = inFilter("이메일 수정: ", 2)
    #print("변경 되었음")

def inFilter(stmt, n):
    while (True):
       if n == 1:
           choice = input(stmt)
           if choice.isalpha() == True or choice == '':pass
           else:return int(choice)
       elif n == 2:
            choice = input(stmt)
            if choice.isdigit() == True or choice == '': pass
            else: return choice
       elif n == 3:
            choice = input(stmt)
            if choice.isalpha() == True or choice == '': pass
            else: return  int(choice)




def intInFilter(stmt):
    while (True):
        value = input(stmt)
        if value.isdigit() == True or value == '':
            pass  #os.system('cls')
        else:
            break
    return value


if __name__ == '__main__':
    memlist = []
    while True:
        choice = inFilter("-> ", 3)
        if choice == "0":
             createDBInit()
        elif choice == "1":
            memberAdd()
        elif choice == "2":
             memberAllList()
        elif choice == "3":
            memlist = memberSearch()
        elif choice == "4":
            memberModify()
        elif choice == "5":
            os.system("cls")
        elif choice == "6":
            sys.exit(1)
        else:
            print("잘못된 번호! 다시 입력바랍니다.")



    main()