num1 = int(input("첫 번쨰 숫자 입력 : "))
op = input("연산자 입력 : ")
num2 = int(input("두 번째 숫자 입력 : "))

if (op == "+") :
    print("수식결과",num1,op,num2, "=",num1 + num2)

elif (op == "-"):
    print("수식결과",num1,op,num2, "=",num1 - num2)

elif (op == "*"):
    print("수식결과",num1,op,num2, "=",num1 * num2)

else:
    print("해당 없음")