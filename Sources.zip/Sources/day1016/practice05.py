i=0
while i < 1000000:
    print("%d : ㅣ ㅣ" % i)
    i=i+1