dan = 2
while dan <= 9:
    print("==",dan,"단 ==")
    i = 1

    while(i <=9):
        print(dan,"*",i,"=",dan*i)
        i=i+1
    dan=dan+1