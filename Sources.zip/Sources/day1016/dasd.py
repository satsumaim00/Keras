import pymysql

#DB연결
conn = pymysql.connect(host='localhost', user='root', password='1234', db='testdb', charset='utf8')


curs = conn.cursor() # db 테이블 및 결과셋 커서 연결

sql = "select * from member"  #  실제 테이블 쿼리 문자열

curs.execute(sql)  # curs.execut("select * from member")


#sql 문장이 실행된 후에 결과를 가져옴
rows = curs.fetchall()

print(rows)

conn.close()
