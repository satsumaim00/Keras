# number = int(input("Number in : "))
# if number >= 100:
#     print("100 Over : ", number)
# else:
#     print("100 under : ", number)
#

tot = 95
grade = 4.512121
print("총점 :", tot)
print("평균 :", grade)
print("총점 : :", tot, "평균 : ", grade)
print("\n총점 : {} 평균 : {:3.1f}".format(tot, grade))

print(type(tot))

