name = "Nam"
classid = "20190101"
print("Name : ", name)
print("Class id : ", classid)