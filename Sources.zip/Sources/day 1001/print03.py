# \n, " "

print("Hello")
print("Powerful Python", end='\n')
print("Fun Python")

print("Hello")
print("Easy Python", end=' ')
print("Fun Python", end=' ')