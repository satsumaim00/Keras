# int, float

abc = "10"
print(int(abc) + 10)    #int(변수 또는 정수) 문자형숫자 숫자
xyz = "3.14"
print(float(xyz) * 5 * 5) #float(변수 또는 실수) 문자형실수 실수
