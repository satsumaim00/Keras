item = input("전자 장비 이름 입력: ")
SN = 26

sts = item + str(SN)
print('입력하신 장비이름과 넘버는 %s ' % sts)
