# 문자열은 인덱스 번호가 부여가 된다(문자단위로) strTemp 쓴 개수만큼 문자열 입력
strTemp = input("아무 문자열이나 입력하세요: ")
print("strTemp : ", strTemp)
print("strTemp : %s" % strTemp )

print('strTemp[0] : ', strTemp[0])
print('strTemp[1] : ', strTemp[1])
print('strTemp[2] : ', strTemp[2])