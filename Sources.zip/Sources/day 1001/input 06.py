# 문자열 인덱스 번호가 역으로 가능하다.

word = input('문자열 입력 바람 5글자 이상: ')
print(word[-1])
print(word[-2])
print(word[-3])
print(word[-4])
print(word[-5])
