# 정수 입력
#   print('정수 입력: ', end='')
#   score = input()
#   score = int(score)

score = int(input('정수입력: '))

print(score + 10)

# 실수 입력
# print("실수 입력: ", end='')
# grade = input()
#  = float(grade)

grade = float(input('실수입력: '))
print(grade)
