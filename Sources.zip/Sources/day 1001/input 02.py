# 문자, 문자열 입력
ID = input("사용자 ID를 입력하시오: ")
PWD = input("사용자 패스워드를 입력하시오: ")

# 어떤 인증 절차 코드 작성...
print("사용자ID %s" % ID)
print("사용자PASS %s" % PWD)
