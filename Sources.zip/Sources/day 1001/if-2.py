# if 4가지 형식
# 단독 if , if~elif~elif...else, 중첩if(if문안에 if)

num = int(input("정수입력: "))

if num > 100:
    print("100보다 크다")

if num > 100:
    print("100보다 크다")
else:
    print("100보다 작다")

# A와 B가 같고, B와 C가 같으면 A와 C가 같다
A = 10; B = 10; C =20
if  A == B:
    if B == C:
        if A == C:
            print("A와 C는 같다.")
    else:
        print("A와 C는 같지 않다.")

else:
    print("A와 C는 같지 않다.")

