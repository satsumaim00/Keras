import time
import winsound
#파이썬에서 제공하는 기본 라이브러리 함수(API)
print("안녕 만나서 반가워")
winsound.beep(600, 500) # 600 음높이, 500: 0.5초
time.sleep(1) #1초를 의미
print("제이름은 ss 라고 합니다")
time.sleep(1) #1초를 의미
print("나는 파이썬을 하고 있어")
