# 함수1: 매개변수 o, 리턴( 반환값) x
# 함수2: 매개변수 x, 리턴( 반환값) o
# 함수3: 매개변수 o, 리턴( 반환값) o
# 함수4: 매개변수 x, 리턴( 반환값) x

#파이썬 함수 구성 : def 함수명(매개변수):
#                       return (변수,값,레퍼펀스)

def func01(iValue, sName, fPI):
    print(iValue, sName, fPI)

def func02():
    #sGrade = input("학점 입력: ")
    #return sGrade
    return input("학점 입력: ")

def func03(fAvg):
    result = ''
    if fAvg >= 90:
        result = 'A'
    elif 89 >= fAvg >= 80:
        result = 'B'
    else:
        result = "C,D,F"
    return result

def displayMenu():
    print("1. 새게임")
    print("2. 저장게임")
    print("3. 설정")
    print("4. 종료")
    print("선택>> ")

def main():
    func01(100, 'Moon', 3.14)
    print(func02()) #sGrade = func02()
    hakjum = func03(float(input('평균값을 입력: ')))
    print(hakjum)

main()