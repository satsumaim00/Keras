# 키보드 이벤트

from tkinter import *
from tkinter import messagebox

def keyEvent(event):
    messagebox.showinfo("키보드 이벤트", "눌린키: " + chr(event.keycode))

window = Tk()

window.bind("<key>", keyEvent)

window.mainloop()