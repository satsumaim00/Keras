from tkinter import *  # 윈도우 위젯을 지원하는 라이브러리

window = Tk()
window.title("윈도우 창연습")
window.geometry("400x100")
window.resizable(width=False, height=False)



window.mainloop()
