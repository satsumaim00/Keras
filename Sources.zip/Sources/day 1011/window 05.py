from tkinter import *  # 윈도우 위젯을 지원하는 라이브러리
from tkinter import  messagebox
def myFunc():
    messagebox.showinfo("버튼", "ㅎㅅㅎ")


window = Tk()
window.title("이미지 클릭시 메세지박스 띄우기")




photo = PhotoImage(file="aaaa.png")
button = Button(window, image=photo, command=myFunc)

button.pack()
window.mainloop()
