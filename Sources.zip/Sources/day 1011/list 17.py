# 문자열 길이를 이용한 출력

letter = ['a', 'b', 'c','a', 'b', 'c','a', 'b', 'c','a', 'b', 'c']
print(letter)

cnt = len(letter)

for i in range(cnt):
    print(letter[i], end='')

shopping = []
shopping.append('두부')
shopping.append('양배추')