studentListROW = []
studentListCOL = []
for i in range(0, 3):
    print(i + 1, "번")
    for j in range(0, 3):
        studentListCOL.append(int(input(' 점수 입력: ')))

        studentListROW.append(studentListCOL)
    studentListCOL = []

for stu in studentListROW:
    tot = 0
    for score in stu:
        tot += score
    avg = tot / len(stu)
    if 100 <= avg >= 90:    stu.append('A')
    elif 89 <= avg >= 80:    stu.append('B')
    elif 79 <= avg >= 70:    stu.append('C')
    elif 69 <= avg >= 60:   stu.append('B')
    else: stu.append('F')

print(studentListROW)

print('=== 최종 성적 리스트 ====')
print("번호\t 점수1\t 점수2\t 점수3\t 총점\t 평균\t 학점\t")
for i in range(0, 3):
   for j in range(0, 6):
       print(studentListROW[i][j], end='\t\t')
    print()