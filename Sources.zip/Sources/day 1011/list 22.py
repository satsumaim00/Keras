studentListROW = []
studentListCOL = []
for i in range(0, 3):
    print(i + 1, "번")
    for j in range(0, 3):
        studentListCOL.append(int(input(' 점수 입력: ')))

        studentListROW.append(studentListCOL)
    studentListCOL = []

for stu in studentListROW:
    tot = 0
    for score in stu:
        tot += score
    avg = tot / len(stu)

print(studentListROW)
