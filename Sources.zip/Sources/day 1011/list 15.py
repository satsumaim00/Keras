# 특정입력받아서 리스트에저장, 종료시 엔터키 입력

marvelName = [] #리스트 초기화
while True:
    name = input('마블 영웅 이름 입력(종료시 엔터키)>> ')

    if name == '':
        break

    marvelName.append(name)

print('마블 영웅 리스트 : ')

for name in marvelName:
    print(name, end=",")

for i in range(len(marvelName)):
    print(marvelName[i], end="")

