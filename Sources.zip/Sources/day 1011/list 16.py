# 리스트 문자열에서 인덱스를 이용한 출력

text = "Will is power"
print(text[0], text[3], text[-1])

flist = ["apple", "banana", "tomato", "peach", "pear"]
print(flist[0], flist[3], flist[-1])


#리스트 또는 문장ㄹ에서 슬라이싱에서 원하는 범위만큼 출력

sqr = [0,1,2,5,6,8,9,22,44]
print(sqr[3:6])
print(sqr[3:])

#리스트 두개 합치기
marvel = ['스파이더맨', '토르', '아이언맨']
dc = ['슈퍼맨', '배트맨', '아쿠아맨']

hreos = marvel + dc #문자열합치기
print(hreos)

for name in hreos:
    print(name)

#리스트를 연속적인 숫자만큼 추가하기
values = [1,2,3] * 3
print(values)
