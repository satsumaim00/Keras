# 리스트 중복되는 값이 안들어감

listID = []

listID.append(2001)
listID.append(2002)
listID.append(2003)

for i in listID:
    print(i, end='')

for m in listID:
    if listID.index(m) == 2: #두번쨰 인섹스
        print("%d %s" % (listID.index(m), m))

    for m in listID:
        if listID.index(m) == 2:  # 두번쨰 인섹스
           listID[2] = 'DDD'
print(listID)