i = 50

while( i > 0 ) :
    print(i, end=' ')
    i = i - 1
print('\n')

for k in range(50, -1, -1):
    print(k, end=' ')