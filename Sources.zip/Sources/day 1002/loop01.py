#for (int i = 1; i <= 100; i++)
for i in range(1, 101 , 2):
    print(i, end=' ')
print('\n')
for i in range(0, 101, 2):
    print(i, end=' ')
print('\n')
for i in [1,2,3,4,5]:
    print(i, end=' ')