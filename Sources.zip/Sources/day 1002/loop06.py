# 1 ~ 100 까지...
for i in range(1, 101, 1):

    if i == 51:
        break # 아랫 문장이 아무리 많아도 51이 되면 수행x
    print(i, end=' ')
print()
for i in range(1, 101, 1):

    if i == 20:
        continue
    print(i, end=' ')
    