# 문자열의 모든 글자 뒤에 %를 붙여서 출력

ss = "파이썬 (ㅇㅅㅇ)b"

sslen = len(ss) # 문자열이 길이 값을 숫자로 알수 있음

for i in range(0, sslen): # for i in range(0, len(ss)): 둘다 같은거
    print(ss[i] + '$', end='')


