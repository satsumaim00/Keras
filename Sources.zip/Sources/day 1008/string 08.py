# 문자열 함수 count(), find(), index()

ss = "Process finished with exit code"

#count() - 문자열 범위에서 찾고자하는 문자 몇개 있는지?
res = ss.count('with')
print(res)

res = ss.count('e')
print(res)

#find() 문자열에서 문자를 찾음
res = ss.find('with')
print(res)

#index()
res = ss.index('with')
print(res)
res = ss.index('Process')
print(res)

#startwith() 그 단언가 시작할 때는 있으면 True 업스면 False
res = ss.startswith('with')
print(res)

#endswtith() 그 단어가 마지막부분에 있으면 True, 없으면 False
res = ss.endswith('code')
print(res)
res = ss.endswith('hello')
print(res)

ress = ss.startswith('Process')
resss = ss.endswith('code')
if ress == True and resss == True:
    print("(", ss , ")")

ss = input('아무거나 문자열을 입력하시오: ')
print("출력할 문자열 ==> ", end='')

if ss.startswith('(') == False:
    print("(", end='')
    
print(ss, end='')

if ss.endswith('(') == False:
    print(")", end='')



