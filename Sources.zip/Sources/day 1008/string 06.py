# 문자열 함수 -> 대문자 소문자 변환하기 함수
# upper(), Lower(), swapcase(), title()

ss = 'Python is Easy. 그래서 programing이 재미있습니다.'

up = ss.upper()
print(up)

lo = ss.lower()
print(lo)

sw = ss.swapcase()
print(sw)

ti = ss.title()
print(ti)

