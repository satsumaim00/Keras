def dateConvert(date):
    temp = date.split('/')
    newdate = str(temp[0] + '년')
    newdate += str(temp[1] + '년')
    newdate += str(temp[2] + '년')
    return newdate

def main():
    indate = input('날짜 년월일 입력: ')
    #newdate = dateConvert(indate)
    #print(newdate)

main()
