str = "hello world"

print(str[0])
print(str[1])
print(str[2])
print(str[3])
print(str[4])
print(str[5])
print(str[6])
print(str[7])
print(str[8])
print(str[9])
print(str[10])
print(str[11]) # 여기서부턴 출력 없음 그리고 에러 발생함


