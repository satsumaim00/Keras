# 문자열 추가하기

org = "Hello"
des = "World"

str = org + " " + des
print(str)

#문자열 길이
ss = "alasmkdmsdmakdlsakdlaskmdald"
slen = len(ss)
print("ss의 문자열의 길이는 : ", slen)
