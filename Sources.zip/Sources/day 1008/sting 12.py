# 문자열 변경 -> replace()

ss = '열심히 파이썬 공부 중'

res = ss.replace('파이썬','Python')
print(res)