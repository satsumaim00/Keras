def aaa():
    print("AAA함수 시작")
    ccc()
    ddd()
    print("AAA함수 끝")
    #pass  아무것도 하지말라는 뜻이래요

def bbb():
    print("BBB함수 시작")
    print("BBB함수 끝")

def ccc():
    print("CCC함수 시작")
    print("CCC함수 끝")

def ddd():
    print("DDD함수 시작")
    bbb()
    print("DDD함수 끝")

def main():
    print("메인함수 시작")
    aaa()
    print("메인함수 끝")

main()