# 1. 반복 기초  -   loopbasic
# 2. 구구단 한단만 출력 -> oneGuGudan
# 3. 콘솔 재입력 예제  -> console input
# 4. 전체 구구단 출력  -> gugudanFull
# 5. 별모양 출력     -> starPrint
# 6. 삼각형 별모양 출력  -> triangLePrint
# 7. 구구단 게임 ->gameGuGuGuDan
# 8. 게임
import aaaa.aaaaa as sf

def main():
    while True:
        sf.menudisplay()
        choice = int(input())

        if choice == 1:
            sf.loopbasic()

        elif choice == 2:
            sf.oneGuGudan()
        elif choice == 3:
            sf.console()
        elif choice == 4:
            sf.gugudanFull()
        elif choice == 5:
            sf.starPrint()
        elif choice == 6:
            sf.triangLePrint()
        elif choice == 7:
            sf.gameGuGuGuDan()
        elif choice == 8:
            print("프로그램 종료")
            break
        else:
            print("번호 잘못입력 되었습니다.")
main()