#성적 처리

stuCnt = 50  # 학생 수

def sunujkin():
    global stuCnt
    pass

def rankin():
    global  stuCnt
    pass
