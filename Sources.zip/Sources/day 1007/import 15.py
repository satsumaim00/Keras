n = int(input("어떤 수를 판별할까요? "))
sucess = True

for t in range(2, n, 1):  #14번 비교 문장이랑같음
    if n % t == 0:
        sucess = False
        break

if sucess == True:
    print("%d는 소수 입니다." % n)
else:
    print("%d는 소수아니다." % n)
