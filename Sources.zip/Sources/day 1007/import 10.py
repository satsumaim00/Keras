

cm = float(input("키가 몇 cm에요? "))


ss = (cm - 100) * 0.9
dd = (cm - 100) * 1.2
ff = (cm - 100) * 0.8

print("적정 몸무게: %f" % (ss))
print("과체중 위험 기준: %f" % (dd))
print("저체중 위험 기준: %f" % (ff))

parkingTime = int(input("주차시간 입력: "))

unitT = parkingTime // 15

fee = unitT * 1000

print("주차시간 : ", parkingTime, "분")
print("주차요금 : ", fee, "원")
