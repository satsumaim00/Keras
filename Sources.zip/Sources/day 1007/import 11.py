score = int(input("점수입력: "))

if score >= 90 :
    print("장학금 대상자입니다.")
print("수고하셨습니다.")

time = int(input("시간입력: "))
time1 = time - 6

if time1 <0 :
    time1 += 24

print("현재시간 : %d시" % time)
print("이전 시간 : %d시" % time1)



