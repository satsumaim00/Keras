# 구글 번역기를 이용한 번역 프로그램

import  webbrowser  #PC에 기본으로 설정된 브라우저를 이용
url = "http://www.naver.com"

webbrowser.open(url) #webrowser