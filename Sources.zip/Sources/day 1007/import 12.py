# 4로 나누어 떨어지고, 100으로 나누어 떨어지지 않음.
# 400ㅡ로 나누어 떨어짐.
import calendar

score = int(input("윤년을 판단하기(2019): "))
if score % 400 == 0:
    print(score, "년은 윤년입니다.")
    calendar.prmonth(score, 2)
elif score % 100 == 0:
    print(score, "년은 윤년이 아닙니다.")
    calendar.prmonth(score, 2)
elif score % 4 == 0:
    print(score, "년은 윤년입니다.")
    calendar.prmonth(score, 2)
else:
    print(score, "년은 윤년이 아닙니다.")
    calendar.prmonth(score, 2)


#--------------------------------#
print()

if (score % 100 != 0 and score % 4 == 0) or (score % 400 == 0):
    print(score, "년은 윤년입니다.")
    calendar.prmonth(score, 2)
else:
    print(score, "년은 윤년이 아닙니다.")
    calendar.prmonth(score, 2)