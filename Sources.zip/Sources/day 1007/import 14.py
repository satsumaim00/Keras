n = int(input("어떤 수를 판별할까요? "))
sucess = True
print(type(sucess))

t = 2
while t < n:
    if n % t == 0:
        sucess = False
        break
    t = t + 1

if sucess == True:
    print("%d는 소수입니다." % n)
else:
    print("%d는 소수아니다." % n)
