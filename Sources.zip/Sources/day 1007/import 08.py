import calendar

year = int(input("당신이 태어날 년도를 입력하시오: "))
month = int(input("몇 울에 태어 났습니까? "))

print("\n아래는 당신이 태어난 달의 달력입니다.")
calendar.prmonth(year, month)

