letter = "HELLO PYTHON"
encode = ""
ch1 = letter[0]
ch2 = letter[1]
ch3 = letter[2]
ch1 = ord(ch1)+1
ch2 = ord(ch2)+1
ch3 = ord(ch3)+1
encode = encode + chr(ch1) + chr(ch2) + chr(ch3)
print(encode)

letter = input("암호할 문자열 입력: ")
encode = ""

for ch in letter:
    num = ord(ch)
    encode = encode + chr(num + 1)

print("원문: ", letter)
print("암호: ", encode)

