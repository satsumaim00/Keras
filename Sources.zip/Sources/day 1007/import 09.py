kidistance = float(input('킬로미터 단위 입력: '))

miledistance = kidistance * 0.621371

print("입력 값: %f" % (kidistance))
print("입력 값: %f" % (miledistance))