cm = int(input("키가 몇 cm에요? "))
kg = int(input("몸무게가 몇 kg에요? "))
m = cm / 100
bmi = kg / (m * m)
print("당신의 체질량지수는 %.2f" % bmi)

if bmi < 20:
    print("저체중입니다.")
elif 20 <= bmi < 25:
    print("정상체중입니다.")
elif 25 <= bmi < 30:
    print("경도비만입니다.")
elif 30 <= bmi < 40:
    print("비만입니다.")
elif 40 <= bmi:
    print("고도비만입니다.")
