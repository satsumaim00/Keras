letter = "HELLO PYTHON"
encode = ""

for ch in letter:
    num = ord(ch)
    encode = encode + chr(num + 1)

print("원문: ", letter)
print("암호: ", encode)

letter1 = ""

for ch in encode:
    num = ord(ch)
    letter1 = letter1 + chr(num-1)

print("암호: ", encode)
print("원문: ", letter1)


