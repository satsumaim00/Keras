import webbrowser

print("번역할 문장을 입력하시오")
strText = ""; intext = ""
while True:
    print("-> ", end='')
    intext = input()
    if intext == '끝':
        break
    strText = strText + '%OA' + intext

url = "https://translate.google.co.kr/#ko/en/" + strText
webbrowser.open(url)
 