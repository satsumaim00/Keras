def prime(n):
    success = True
    for t in range(2, n ,1):
        if n % t == 0:
            return False
        return True

for t in range(2, 51, 1):
    if prime(t) == True:

        print("%d " % t)

