

#print("당신의 고향은 어디인가요?", end="")
#home = input()
#print("아름다운", home, "출신이군요")

home =  input("당신의 고향은 어디인가요? ")
print("아름다운", home, "출신이군요")




