import webbrowser

text = input("번역할 문장을 입력하시오: ")

url = "http://translate.google.co.kr/#ko/en/" + text

webbrowser.open(url)

url = "http://translate.google.co.kr/#ko/ja/" + text

webbrowser.open(url)

url = "http://translate.google.co.kr/#ko/zh-CN/" + text
webbrowser.open(url)

