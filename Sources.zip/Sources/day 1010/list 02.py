str = [1,2,3,4,5]
str.append(2)
print(str)

str = 10
print(str)