STUDENT = 5

scroesList = []  #학생들의 점수리스트
scoreSum = 0  #총점

for i in range(STUDENT):
    value = int(input("한명의 학생 총점: "))
    scroesList.append(value)
    scoreSum += value

scoreAvg = scoreSum / len(scroesList)

highScoreStudent = 0
for i in range(len(scroesList)):
    if scroesList[i] >= 80:
        highScoreStudent += 1

print("전체 평균은 ", scoreAvg)
print("80점 이상의 학생수는 ", highScoreStudent, "명")
