str = "adfwedfdfsdsgdwerwe"

for i in range(0,3,1):
    print("[%d] -> [%s]" % (i, str[i]) )

for i in str:
    print(i, end=",")