
scoreList = []
sum = 0
for i in range(10):
    #jumsu = int(input('과목 점수를 입력: '))
    #scores.append(jumsu)
    scoreList .append(int(input('과목 점수를 입력: ')))

for i in scoreList :
       sum = sum + scoreList[i]

print(sum)


