aa = [10,20,30]
aa[1] = 200 #1번지 값 수정
print(aa)

bb = [10,20,30]
bb[1:2] = [200,201] # 1번지 값 제외 후 1,2번지 만든다 그릭 3번지
print(bb)

cc = [10,20,30]
cc[1] = [200,201]
print(cc)

dd = [10,20,30]
print(dd)
del(dd[1])
print(dd)