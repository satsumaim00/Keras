# List 사용법

# 1.리스트 초기화
aa = [0,0,0,0,0,0,0]
bb = [1,2,3,4,5,6,7]
cc = [] # 최초 생성 리스트 초기화

aaSize = len(aa)
print(aaSize)

bbSize = len(bb)
print(bbSize)


ccSize = len(cc)
print(ccSize)
print()
str1 = []
for i in range(0, 1000):
    str1.append(i)
    print(str1[i], end='')