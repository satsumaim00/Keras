# 문자열 채우기

ss = "파이썬"

print( ss.center(11) )
print( ss.center(11, '-'))
print( ss.ljust(11) )
print( ss.rjust(11) )
print( ss.zfill(11) )

# 문자열 형식,형태,구성?
s1 = "1234"
print(s1.isdigit())  #현재 문자열이 숫자형태인지 물어보는것
s2 = "abcd"
print(s2.isalpha()) #현재 문자열이 알파벳인지 물어보는것

s3 = "abcd123"
print(s3.isalnum()) #현재 문자열이 알파벳 숫자 있는가?

s4 = "  "
print(s4.isspace()) #현재 문자열이 공백인지?있는지?
